using System;

namespace Temp1
{
  class MainClass
  {
    public static void Main()
    {
		Console.WriteLine ("hello world");
    }
  }
}