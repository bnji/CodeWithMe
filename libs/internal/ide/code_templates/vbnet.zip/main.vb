

Public Class Main
	Public Shared Sub Main()
		System.Console.WriteLine("Hello world!")
	End Sub
End Class

